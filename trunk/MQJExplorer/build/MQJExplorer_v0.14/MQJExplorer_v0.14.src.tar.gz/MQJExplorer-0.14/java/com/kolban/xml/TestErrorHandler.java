/*
 * Copyright (C) 2012 Marco Ratto
 *
 * This file is part of the project MQJExplorer.
 *
 * MQJExplorer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * MQJExplorer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MQJExplorer; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.kolban.xml;

import org.xml.sax.*;

public class TestErrorHandler
    implements ErrorHandler
{

    public TestErrorHandler()
    {
    }

    public void error(SAXParseException saxparseexception)
        throws SAXException
    {
        System.out.println("Error!");
        logInformation(saxparseexception);
    }

    public void fatalError(SAXParseException saxparseexception)
        throws SAXException
    {
        System.out.println("Fatal Error!");
        logInformation(saxparseexception);
        throw (SAXException)saxparseexception.getException();
    }

    public void logInformation(SAXParseException saxparseexception)
    {
        System.out.println("Error at: (" + saxparseexception.getLineNumber() + "," + saxparseexception.getColumnNumber() + ")");
        System.out.println("PublicID: " + saxparseexception.getPublicId());
        System.out.println("SystemID: " + saxparseexception.getSystemId());
        System.out.println("Message: " + saxparseexception.getMessage());
    }

    public void warning(SAXParseException saxparseexception)
        throws SAXException
    {
        System.out.println("Warning!");
        logInformation(saxparseexception);
        throw (SAXException)saxparseexception.getException();
    }
}
